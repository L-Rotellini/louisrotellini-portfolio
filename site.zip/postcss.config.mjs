const config = {
  plugins: {
    "@tailwindcss/postcss": {}, // ✅ le nouveau plugin
    autoprefixer: {},
  },
};

export default config;
