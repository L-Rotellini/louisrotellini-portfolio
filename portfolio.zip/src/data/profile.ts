export const profile = {
  name: "Louis Rotellini",
  title: "Webmaster / Développeur web",
  location: "Lille / Paris",
  email: "louis.rotellini@gmail.com",
  phone: "", // si tu veux l'afficher
  availability: "Disponible pour missions freelance (soir/week-end)",
} as const;
