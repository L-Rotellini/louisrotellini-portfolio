export type Offer = {
  id: string;
  title: string;
  subtitle?: string;
  bullets: string[];
  deliverables?: string[];
  leadTime?: string;     // délai indicatif
  startingAt?: string;   // ex: "à partir de 300€"
};

export const offers: Offer[] = [
  {
    id: "creation-site",
    title: "Création de site vitrine",
    subtitle: "Sites modernes, performants et bien référencés",
    bullets: [
      "Conception et développement sur mesure",
      "Responsive design (mobile, tablette, desktop)",
      "Optimisation SEO technique et performance",
      "Hébergement, mise en ligne et suivi",
    ],
    deliverables: [
      "Site complet clé en main",
      "Code source propre et maintenable",
      "Guide rapide d’administration",
    ],
    leadTime: "1 à 3 semaines selon le projet",
    startingAt: "à partir de 800€",
  },
  {
    id: "integration-web",
    title: "Intégration front-end",
    subtitle: "Landing pages, mini-sites, composants UI",
    bullets: [
      "HTML, CSS, JavaScript — code accessible et maintenable",
      "Intégration fidèle à partir de maquettes Figma",
      "Performances mesurées (Lighthouse > 90)",
      "Debug & QA rapides en collaboration avec l’équipe produit",
    ],
    deliverables: [
      "Section / page prête à intégrer en production",
      "Rapports de compatibilité et performance",
    ],
    leadTime: "48–72h selon complexité",
    startingAt: "à partir de 300€",
  },
  {
    id: "maintenance-wordpress",
    title: "Maintenance WordPress",
    subtitle: "Mises à jour, sécurité, support et correctifs",
    bullets: [
      "Mises à jour de thèmes et extensions",
      "Corrections d’affichage, CSS et contenu",
      "Durcissement léger (sécurité, sauvegardes, rôles)",
      "Améliorations de performance et SEO",
    ],
    deliverables: [
      "Changelog clair",
      "Sauvegarde avant/après intervention",
      "Suggestions d’amélioration",
    ],
    leadTime: "interventions ponctuelles ou récurrentes",
    startingAt: "à partir de 90€ / intervention",
  },
];
