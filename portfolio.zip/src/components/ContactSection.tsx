"use client";

import { Mail, MapPin, MessageSquare } from "lucide-react";
import FadeIn from "@/components/FadeIn";
import { profile } from "@/data/profile";

export default function ContactSection() {
  return (
    <section id="contact" className="space-y-8">
      <FadeIn>
        <h2>Contact</h2>
      </FadeIn>

      <FadeIn delay={0.1}>
        <div className="max-w space-y-6 text-[15px] leading-relaxed">
          <p>
            Vous avez besoin d’un site performant, d’une intégration web ou d’une
            maintenance WordPress&nbsp;? Parlons-en&nbsp;!
          </p>

          <p>
            J’accompagne les entreprises, agences et indépendants dans la création ou
            l’amélioration de leur présence en ligne. Chaque mission débute par un
            échange pour comprendre vos besoins, définir un cadre clair et livrer un
            résultat concret.
          </p>

          <p>
            Vous pouvez me contacter directement par e-mail pour présenter votre projet
            ou obtenir un devis rapide.
          </p>
        </div>
      </FadeIn>

      <FadeIn delay={0.2}>
        <div className="grid gap-6 sm:grid-cols-2 w-full">
          {/* Email */}
          <div className="surface rounded-2xl border border-[--surface-border] p-6 flex flex-col gap-3">
            <Mail className="size-5 text-[--muted]" />
            <div className="text-sm text-[--muted] uppercase tracking-wide">Email</div>
            <a
              href={`mailto:${profile.email}`}
              className="text-lg font-medium underline underline-offset-4 hover:text-[--muted] transition-colors"
            >
              {profile.email}
            </a>
          </div>

          {/* Localisation */}
          <div className="surface rounded-2xl border border-[--surface-border] p-6 flex flex-col gap-3">
            <MapPin className="size-5 text-[--muted]" />
            <div className="text-sm text-[--muted] uppercase tracking-wide">Localisation</div>
            <p className="text-lg font-medium">{profile.location}</p>
          </div>
        </div>
      </FadeIn>

      <FadeIn delay={0.3}>
        <div className="pt-6 text-center">
          <a
            href={`mailto:${profile.email}?subject=Demande de mission freelance&body=Bonjour Louis,%0D%0A%0D%0AJe vous contacte à propos d’un projet web.%0D%0A%0D%0AContexte :%0D%0ABesoins :%0D%0ABudget / Délais :%0D%0A%0D%0AMerci !`}
            className="inline-flex items-center gap-2 rounded-md border px-4 py-3 text-sm hover:bg-[--foreground]/5 transition-colors"
          >
            <MessageSquare className="size-4" />
            <span>Discutons de votre projet</span>
          </a>
        </div>
      </FadeIn>
    </section>
  );
}
